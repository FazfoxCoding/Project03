var x = [];
function setup() {
 createCanvas(240, 120);
 noStroke();
 fill(255, 200);
 for (var i = 0; i < 3000; i++) {
 x[i] = random(-1000, 200);
 print ('the value of x is' + x[i]);
 }
}
function draw() {
 background(0);

 for (var i = 0; i < x.length; i++) {
 x[i] +=0.5;

 var y = i * 0.4;
 x[10] = mouseX - 20;


 ellipse(x[i]+140, y, 25, 10);
 triangle(x[i]+75, y+15, x[i]+75, y+5, x[i]+94, y+10);
 triangle(x[i]+150, y+5, x[i]+150, y+15, x[i]+130, y+10);
 }
}

